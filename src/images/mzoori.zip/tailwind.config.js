/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        mz_teal: "#C1EAE0",
        mz_yellow: "#F6CB02",
      },
      backgroundImage: {
        cta_gradient: "linear-gradient(rgb(56, 189, 248), rgb(186, 230, 253))",
      },
    },
  },

  plugins: [],
};
