const IMAGES = {
    image1 : new URL('./mzoorilogo.png', import.meta.url).href,
    image2 : new URL('./modernpos.png', import.meta.url).href,
    image3 : new URL('./specs.png', import.meta.url).href,
    image4 : new URL('./power.png', import.meta.url).href,
    image5 : new URL('./twitter.png', import.meta.url).href,
    image6 : new URL('./mail.png', import.meta.url).href,
    image7 : new URL('./facebook.png', import.meta.url).href,
    image8 : new URL('./instagram.png', import.meta.url).href,
    image9 : new URL('./linkedin.png', import.meta.url).href,
    image10 : new URL('./mzooriwoman.png', import.meta.url).href,
    image11 : new URL('./cardlogo.png', import.meta.url).href,
    image12 : new URL('./chevronright.png', import.meta.url).href,  
    image13 : new URL('./lightaccent.png', import.meta.url).href, 
    image14 : new URL('./carousellogo.png', import.meta.url).href,  
    image15 : new URL('./faqicon.png', import.meta.url).href, 
}
export default IMAGES